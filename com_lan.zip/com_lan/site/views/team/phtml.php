<?php
     
    // no direct access
    defined( '_JEXEC' ) or die( 'Restricted access' );
     
    //Display partial views
    class LANViewsTeamPhtml extends JViewHTML
    {
		function render()
		{
			return parent::render();
		}
    }