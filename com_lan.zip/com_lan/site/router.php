<?php // no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' ); 

	function LANBuildRoute(&$query)
	{
		$segments = array();
		return $segments;
	}

	function LANParseRoute($segments) 
	{

	}
?>