<?php defined('_JEXEC') or die('Restricted access');
	// No direct access to this file
	
	class EventsControllerAdd extends JControllerBase
	{
		/**
		 * Method to execute the controller.
		 *
		 * @return  void
		 *
		 * @since   12.1
		 * @throws  RuntimeException
		 */
		public function execute()
		{
			$app = JFactory::getApplication();
			
			$return = array("success" => false);
			
			return true;
		}
	}