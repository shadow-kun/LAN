<?php defined( '_JEXEC' ) or die( 'Restricted access' );
   /**
	* @version 		$Id$
	* @package		LAN
	* @subpackage	com_lan
	* @copyright	Copyright 2014 Daniel Johnson. All Rights Reserved.
	* @license		GNU General Public License version 2 or later.
	*/
	
   /**
	* Team Model
	*
	* @oackage 		LAN
	* @subpackage	com_lan
	*/
	
	jimport('joomla.application.component.model');
	
	class LANModelLAN extends JModelLegacy
	{
		
	}
?>