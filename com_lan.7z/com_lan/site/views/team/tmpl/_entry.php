<tr>
  <td>
    <div class="media" id="team-row-<?php echo $this->team->team_id; ?>">
      <div class="media-body">
        <h4 class="media-heading"><?php echo $this->team->team_name; ?></h4>
        
        <p><?php echo $this->team->team_description; ?></p>
		<p><?php echo $this->team; ?></p>
		<p><?php echo $this->id; ?></p>
      </div>
    </div>
  </td>
<tr>