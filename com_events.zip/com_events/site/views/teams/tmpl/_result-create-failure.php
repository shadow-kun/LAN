<div>
	<p><?php echo JText::_('COM_EVENTS_TEAMS_CREATE_FAILURE'); ?></p>
	</br >
	<p class="center"><button class="btn btn-primary" ><?php echo JText::_('COM_EVENTS_TEAMS_BUTTON_BACK'); ?></button></p>
</div>