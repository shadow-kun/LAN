<?php defined( '_JEXEC' ) or die( 'Restricted access' );
	class EventsViewInternetRaw extends JViewHtml
	{
		function render()
		{
			
		}
	}