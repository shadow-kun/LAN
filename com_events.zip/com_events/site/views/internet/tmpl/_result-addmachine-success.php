<div>
	<p><?php echo JText::_('COM_EVENTS_INTERNET_STORE_SUCCESS'); ?></p>
	</br >
	<p class="center"><button class="btn btn-primary" ><?php echo JText::_('COM_EVENTS_INTERNET_BUTTON_BACK'); ?></button></p>
</div>