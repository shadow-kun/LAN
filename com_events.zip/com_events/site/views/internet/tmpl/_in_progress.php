<div>
	<p><?php echo JText::_('COM_EVENTS_INTERNET_IN_PROGRESS'); ?></p>
	
</div>