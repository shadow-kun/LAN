<?php defined( '_JEXEC' ) or die( 'Restricted access' );
	
	/**
	 * @package		LAN
	 * @subpackage	com_lan
	 * @copyright	Copyright 2014 Daniel Johnson. All Rights Reserved.
	 * @license		GNU General Public License version 2 or later.
	 */
	jimport('joomla.application.component.helper');
	
	JHtml::_('behavior.tooltip');
	JHtml::_('behavior.formvalidation');
	$editor = JFactory::getEditor();
	
?>
<div id="details" >
	<fieldset class="adminform">
		<div><?php echo JText::_('COM_EVENTS_TEAM_EDIT_TITLE_LABEL');?><input type="text" name="title" value="<?php echo $this->team->title; ?>" /></div>
		<div><?php echo $editor->display('body', $this->team->body, '100%', '350', '55', '20', false); ?></div>
	</fieldset>
	<div><button class="btn" value="cancel"><?php echo JText::_('COM_EVENTS_TEAM_BUTTON_BACK');?></button>
	<a class="btn btn-primary" onclick="updateTeamDetails()" href="javascript:void(0)"><?php echo JText::_('COM_EVENTS_TEAM_BUTTON_SUBMIT');?></a></div>
</div>
				