<div id="details" >
	<div>
		<p><?php echo JText::_('COM_EVENTS_TEAM_DELETE_DETAILS_LABEL'); ?></p>
	</div>
	<div><button class="btn btn-primary" value="cancel"><?php echo JText::_('COM_EVENTS_TEAM_SUMMARY_CANCEL_LABEL');?></button>
		<a class="btn" name="delete" href="javascript:void(0)" onclick="deleteTeam()"><?php echo JText::_('COM_EVENTS_TEAM_SUMMARY_DELETE_LABEL');?></a></div>
</div>