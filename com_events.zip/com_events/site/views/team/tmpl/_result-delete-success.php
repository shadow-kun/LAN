<div>
	<p><?php echo JText::_('COM_EVENTS_TEAM_DELETE_SUCCESS'); ?></p>
	<p class="center"><a class="btn btn-primary" href="<?php echo JRoute::_('index.php?option=com_events&view=teams'); ?>"><?php echo JText::_('COM_EVENTS_TEAM_BUTTON_BACK'); ?></a></p>
</div>