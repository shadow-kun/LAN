<div>
	<p><?php echo JText::_('COM_EVENTS_TEAM_DELETE_FAILURE'); ?></p>
	</br >
	<p class="center"><a class="btn btn-primary" href="<?php echo JRoute::_('index.php?option=com_events&view=team&id=' . $this->team->id); ?>" ><?php echo JText::_('COM_EVENTS_TEAM_BUTTON_BACK'); ?></a></p>
</div>