<div>
	<h3><font color="red"><?php echo JText::_('COM_EVENTS_ERROR_CHECKIN_FAILURE');?></font></h3>
</div>