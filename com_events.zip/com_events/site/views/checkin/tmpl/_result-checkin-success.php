<div>
	<h3><font color="green"><?php echo JText::_('COM_EVENTS_CHECKIN_SUCCESS');?></font></h3>
</div>