
<h2>Stuff</h2>
<p><?php 
$app = JFactory::getApplication('site');
echo $app->input->getWord('layout', 'default'); ?></p>
<p><?php echo $this->data; ?></p>
