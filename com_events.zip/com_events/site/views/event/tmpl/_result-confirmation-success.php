<div>
	<p><?php echo JText::_('COM_EVENTS_EVENT_CONFIRMATION_SUCCESS'); ?></p>
	<p class="center"><button class="btn btn-primary" ><?php echo JText::_('COM_EVENTS_EVENT_BUTTON_BACK'); ?></button></p>
</div>