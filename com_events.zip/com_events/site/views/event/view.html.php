<?php defined('_JEXEC') or die('Restricted access');
	// No direct access to this file

	/**
	 * Event Html View.
	 *
	 * @package  COM_EVENTS
	 *
	 * @since   12.1
	 */
	class EventsViewEventHtml extends JViewHtml
	{
		/**
		 * Render some data
		 *
		 * @return  string  The rendered view.
		 *
		 * @since   12.1
		 * @throws  RuntimeException on database error.
		 */
		 
		 
		//protected $model;
		
		public function render()
		{
			
			$app = JFactory::getApplication();
			$layout = $this->getLayout();
			
			$this->params = JComponentHelper::getParams('com_events');

			$model = new EventsModelGetEvent;
			
			// Prepare some data from the model.
			$data = array(
				'event' => $this->model->getEvent()
			);

			$data = $data . "TEST";
			
			// Convert the data to JSON format.
			
			//display
			return parent::render();
		}
	}

	
	
?>