<div>
	<p><?php echo JText::_('COM_EVENTS_COMPETITION_UNREGISTER_FAILURE'); ?></p>
	</br >
	<p class="center"><button class="btn btn-primary" ><?php echo JText::_('COM_EVENTS_COMPETITION_BUTTON_BACK'); ?></button></p>
</div>