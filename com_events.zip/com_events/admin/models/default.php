<?php defined( '_JEXEC' ) or die( 'Restricted access' );
   /**
	* @version 		$Id$
	* @package		Events Party!
	* @subpackage	com_events
	* @copyright	Copyright 2014 Daniel Johnson. All Rights Reserved.
	* @license		GNU General Public License version 2 or later.
	*/
	
   /**
	* Team Model
	*
	* @oackage 		Events Party!
	* @subpackage	com_events
	*/
	
	jimport('joomla.application.component.model');
	
	class EventsModelLAN extends JModelLegacy
	{
		
	}
?>